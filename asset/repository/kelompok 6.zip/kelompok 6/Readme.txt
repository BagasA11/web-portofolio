Komputasi fisika

	Author:
	 -> Fernando Oloan Tambun
	 -> Bagas Rayhan Sebastian
	 -> Akfi Rozada
	 -> Revrans GC
	 -> Bayu Dewanto
